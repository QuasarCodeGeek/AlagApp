<?php
require("../connector.php");

    session_start();
    if(isset($_POST["submit"])){
        $owner = $_POST["userid"];
        $name = $_POST["petname"];
        $type = $_POST["pettype"];
        $breed = $_POST["petbreed"];
        $weight = $_POST["petweight"];
        $mark = $_POST["petmark"];
        $bdate = $_POST["petbdate"];
        $age = $_POST["petage"];
        $gender = $_POST["petgender"];

        if($owner=="" || $name=="" || $type=="" || $breed==""){
            $_SESSION["trigger"] = "newEPet";
            echo "<script>window.location='../profile.php?userid=".$owner."'</script>";//Fields Required
        } else {
            $sql = "INSERT INTO alagapp_db.tbl_petprofile(
                userid,
                petname,
                pettype,
                petbreed,
                petweight,
                petmark,
                petbdate,
                petage,
                petgender) VALUES(
                    :userid,
                    :petname,
                    :pettype,
                    :petbreed,
                    :petweight,
                    :petmark,
                    :petbdate,
                    :petage,
                    :petgender)";

            $result = $connect->prepare($sql);

            $values = array(
                ":userid" => $owner,
                ":petname" => $name,
                ":pettype" => $type,
                ":petbreed" => $breed,
                ":petweight" => $weight,
                ":petmark" => $mark,
                ":petbdate" => $bdate,
                ":petage" => $age,
                ":petgender" => $gender
            );

            $result->execute($values);

            if($result->rowCount()>0) {
                $_SESSION["trigger"] = "newPet";
                echo "<script>window.location='../profile.php?userid=".$owner."'</script>";//Success
            } else {
                $_SESSION["trigger"] = "newEPet";
                echo "<script>window.location='../profile.php?userid=".$owner."'</script>";//Not Success
            }
        }
    }

    $sql = "SELECT * FROM alagapp_db.tbl_userlist";
    $res = $connect->query($sql);
    $res->execute();
    echo    "
            <form action='api/newData/addPet.php' method='POST'>
            <h1>New Pet Profile</h1><br>
            <div class='input-group'>
            <span class='input-group-text'>Pet Name</span>
            <input class='form-control' type='text' placeholder=\"Name\" name='petname' required>
            <span class='input-group-text'>Species</span>
            <input class='form-control' type='text' placeholder=\"Species\" name='pettype' required>
            <span class='input-group-text'>Breed</span>
            <input class='form-control' type='text' placeholder=\"Breed\" name='petbreed' required>
            </div><br>
            <div class='input-group'>
            <span class='input-group-text'>Birth Date</span>
            <input class='form-control' type='date' name='petbdate' required>
            <span placeholder=\"Age\" class='input-group-text'>Age</span>
            <input class='form-control' type='text' placeholder='Age' name='petage'>
            <label class='input-group-text' for='inputGenderSelect'>Sex</label>
                <select class='form-select' name='petgender' id='inputGenderSelect' required>
                    <option selected''>-- Select Sex --</option>
                    <option value='M'>M</option>
                    <option value='F'>F</option>
                </select>
            </div><br>
            <div class='input-group'>
            <label class='input-group-text' for='inputGroupSelect'>Owner</label required>
            <select class='form-select' name='userid' id='inputOwnerSelect'>
                    <option selected''>-- Select Owner --</option>";
                    $i=1;
                    if($res->rowCount()>0){
                        while($Row = $res->fetch(PDO::FETCH_ASSOC)){
                            echo "<option value='".$Row['userid']."'>".$Row['userfname']."</option>";
                            $i++;
                        }
                    }
                        
                echo "</select>
            <span class='input-group-text'>Weight(kg)</span>
            <input class='form-control' type='float' placeholder=\"Weight\" name='petweight'>
            <span class='input-group-text'>Color/Marking</span>
            <input class='form-control' type='text' placeholder=\"Color/Marking\" name='petmark' required>
            </div><br>

            <div class='d-grid gap-2 d-md-flex justify-content-md-end'>
                <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                <button id='submitPetEdit' type='submit' name='submit' class='btn btn-primary'>Add Pet Profile</button>
            </div>
        </form>";
?>