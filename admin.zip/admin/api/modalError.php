<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" id="triggerENewUser" data-bs-toggle="modal" data-bs-target="#toastModalE1" hidden>
    Launch demo modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center  text-danger">
          Unable to add New User!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewPet" data-bs-toggle="modal" data-bs-target="#toastModalE2" hidden>
    Launch demo modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Pet!
        </div>
      </div>
    </div>
  </div>


  <button type="button" class="btn btn-primary" id="triggerENewSched" data-bs-toggle="modal" data-bs-target="#toastModalE3" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Schedule!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewCard" data-bs-toggle="modal" data-bs-target="#toastModalE4" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Vaccination!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewNote" data-bs-toggle="modal" data-bs-target="#toastModalE5" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE5" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Prescription!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewVaccine" data-bs-toggle="modal" data-bs-target="#toastModalE6" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE6" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Vaccine!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewSymptom" data-bs-toggle="modal" data-bs-target="#toastModalE7" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE7" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Symptom!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerENewRecord" data-bs-toggle="modal" data-bs-target="#toastModalE15" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE15" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to add New Pet Medical History!
        </div>
      </div>
    </div>
  </div>








  <!--        =============================================           -->


  <!-- Button trigger modal -->
<button type="button" class="btn btn-primary" id="triggerEEditUser" data-bs-toggle="modal" data-bs-target="#toastModalE8" hidden>
    Launch demo modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE8" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update User Profile!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditPet" data-bs-toggle="modal" data-bs-target="#toastModalE9" hidden>
    Launch demo modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE9" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Pet Profile!
        </div>
      </div>
    </div>
  </div>


  <button type="button" class="btn btn-primary" id="triggerEEditSched" data-bs-toggle="modal" data-bs-target="#toastModalE10" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE10" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Schedule Information!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditCard" data-bs-toggle="modal" data-bs-target="#toastModalE11" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE11" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Vaccination!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditNote" data-bs-toggle="modal" data-bs-target="#toastModalE12" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE12" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Prescription!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditVaccine" data-bs-toggle="modal" data-bs-target="#toastModalE13" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE13" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Vaccine!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditSymptom" data-bs-toggle="modal" data-bs-target="#toastModalE14" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE14" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Symptom!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerEEditRecord" data-bs-toggle="modal" data-bs-target="#toastModalE16" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalE16" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to update Pet Medical History!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="triggerFailed" data-bs-toggle="modal" data-bs-target="#toastModalFailed" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastModalFailed" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to send SMS to recipients!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="failedDelCard" data-bs-toggle="modal" data-bs-target="#toastFailedCard" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastFailedCard" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to Delete Vaccination!
        </div>
      </div>
    </div>
  </div>

  <button type="button" class="btn btn-primary" id="failedDelNote" data-bs-toggle="modal" data-bs-target="#toastFailedNote" hidden>
    modal
  </button>

  <!-- Modal -->
  <div class="modal fade" id="toastFailedNote" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center text-danger">
          Unable to Delete Prescription!
        </div>
      </div>
    </div>
  </div>